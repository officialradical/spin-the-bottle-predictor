# Spin the Bottle Predictor

A mobile-friendly static demo homepage.

## Files
- `index.html` — page structure
- `styles.css` — responsive styling
- `app.js` — demo button interactions

## Publish
Upload these files to the root of the `main` branch and enable GitHub Pages from `main` / `(root)`.

Note: Registration, user accounts, voucher validation, admin tools and payments require a secure backend. The UP/DOWN demo is illustrative only.
