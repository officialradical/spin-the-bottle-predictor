# Spin the Bottle Predictor

Static demo site with Supabase email/password sign-up and sign-in.

## Setup
1. In `app.js`, replace `PASTE_YOUR_PROJECT_URL_HERE` with your Supabase Project URL.
2. Replace `PASTE_YOUR_PUBLISHABLE_KEY_HERE` with the Supabase Publishable key (`sb_publishable_...`). Never use a secret or service-role key in browser code.
3. Commit `index.html`, `styles.css`, and `app.js` to the root of the GitHub Pages repository.
4. In Supabase Authentication URL Configuration, set Site URL to `https://officialradical.github.io` and add `https://officialradical.github.io/spin-the-bottle-predictor/` to Redirect URLs if needed.
5. Email/password sign-in must be enabled under Authentication > Sign In / Providers. Email confirmation may need to be confirmed from the inbox.

The UP/DOWN output is random demo content, not a real predictor. Admin tools, vouchers, and payments are not implemented.
