// Paste your Supabase Project URL and Publishable key below.
const SUPABASE_URL = "PASTE_YOUR_PROJECT_URL_HERE";
const SUPABASE_PUBLISHABLE_KEY = "PASTE_YOUR_PUBLISHABLE_KEY_HERE";

const configured = SUPABASE_URL.startsWith("https://") &&
  SUPABASE_PUBLISHABLE_KEY.startsWith("sb_publishable_");
const supabaseClient = configured && window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY)
  : null;

const $ = (id) => document.getElementById(id);
const message = (text) => { $("message").textContent = text; };

$("year").textContent = new Date().getFullYear();
$("predictBtn").addEventListener("click", () => {
  const result = Math.random() < 0.5 ? "UP" : "DOWN";
  $("result").textContent = "Demo result: " + result + " (random example only)";
});

async function authAction(action) {
  if (!supabaseClient) {
    message("Supabase is not configured yet. Add your Project URL and Publishable key in app.js, then commit the file.");
    return;
  }
  const email = $("email").value.trim();
  const password = $("password").value;
  if (!email || password.length < 6) {
    message("Enter a valid email and a password with at least 6 characters.");
    return;
  }
  $("signupBtn").disabled = true;
  $("signinBtn").disabled = true;
  try {
    let response;
    if (action === "signup") {
      response = await supabaseClient.auth.signUp({ email, password });
    } else {
      response = await supabaseClient.auth.signInWithPassword({ email, password });
    }
    if (response.error) throw response.error;
    if (action === "signup" && !response.data.session) {
      message("Account request created. Check your email for a confirmation link before signing in.");
    } else {
      message("You're signed in as " + (response.data.user?.email || email) + ".");
      $("signoutBtn").classList.remove("hidden");
    }
  } catch (error) {
    message(error.message || "Something went wrong. Please try again.");
  } finally {
    $("signupBtn").disabled = false;
    $("signinBtn").disabled = false;
  }
}

$("signupBtn").addEventListener("click", () => authAction("signup"));
$("signinBtn").addEventListener("click", () => authAction("signin"));
$("signoutBtn").addEventListener("click", async () => {
  if (!supabaseClient) return;
  const { error } = await supabaseClient.auth.signOut();
  message(error ? error.message : "You have signed out.");
  $("signoutBtn").classList.add("hidden");
});
