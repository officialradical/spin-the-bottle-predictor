# Spin the Bottle Predictor — website starter

A responsive landing page and UI preview for **Spin the Bottle Predictor**. Includes a login/register modal and sample UP/DOWN display.

## Important: current status
This is a **front-end preview**, not a production-ready service. Login and registration are intentionally non-functional: no credentials are collected or stored. The demo outcome is random and must not be described as a reliable prediction. Payment, voucher redemption, persistent user dashboards, and admin management need to be connected to a real backend before launch.

## Run it
1. Extract this ZIP.
2. Open `index.html` in a browser, or upload the files to a static host for a visual preview.
3. Do not use the preview form for real users or payments.

## Production checklist
Before accepting real users:
- Connect Supabase Auth or another reputable authentication provider.
- Enable email confirmation, password reset, rate limiting, and secure session handling.
- Create database tables for profiles, voucher records, redemptions, and payment references. Apply row-level security policies and test them.
- Generate vouchers only on the server, store hashed voucher codes, and make each code redeemable only once.
- Integrate a payment provider using server-side functions. Keep secret API keys in server environment variables; never place secret keys in browser JavaScript or public GitHub repositories.
- Verify payment status on the server using the provider's API or signed webhook before granting access. Never grant access just because a browser says payment succeeded.
- Restrict admin operations with server-verified roles. Never rely on a hidden admin button or a client-side email check.
- Publish behind HTTPS, add privacy/terms/support pages, and test mobile layouts and account recovery.
- If the site involves wagering or paid predictions, confirm local legal requirements and provider terms before enabling payments.

## Suggested implementation
- Front end: this HTML/CSS/JavaScript starter.
- Authentication/database: Supabase.
- Payments: a supported payment provider for Ghana, with server-side payment initialization and verification.
- Hosting: a static host for the front end and server/edge functions for protected operations.

## Customization
- Brand and page text: `index.html`
- Colors and responsive styling: `styles.css`
- Preview interactions: `app.js`
