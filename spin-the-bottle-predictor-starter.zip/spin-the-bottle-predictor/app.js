const modal = document.getElementById("authModal");
const title = document.getElementById("modalTitle");
const subtitle = document.getElementById("modalSubtitle");
const submit = document.getElementById("submitAuth");
const notice = document.getElementById("authNotice");
const registerTab = document.getElementById("registerTab");
const loginTab = document.getElementById("loginTab");
const form = document.getElementById("authForm");
let mode = "register";

document.getElementById("year").textContent = new Date().getFullYear();

function openModal(nextMode = "register") {
  setMode(nextMode);
  modal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
}
function closeModal() {
  modal.classList.add("hidden");
  document.body.style.overflow = "";
}
function setMode(nextMode) {
  mode = nextMode;
  const isRegister = mode === "register";
  title.textContent = isRegister ? "Create your account" : "Welcome back";
  subtitle.textContent = isRegister ? "Get started with your own dashboard." : "Log in to continue to your dashboard.";
  submit.innerHTML = isRegister ? "Create account <span>↗</span>" : "Log in <span>↗</span>";
  registerTab.classList.toggle("active", isRegister);
  loginTab.classList.toggle("active", !isRegister);
  document.getElementById("password").autocomplete = isRegister ? "new-password" : "current-password";
}
document.getElementById("loginNav").addEventListener("click", () => openModal("login"));
document.getElementById("heroLogin").addEventListener("click", () => openModal("login"));
document.getElementById("registerNav").addEventListener("click", () => openModal("register"));
document.getElementById("heroRegister").addEventListener("click", () => openModal("register"));
registerTab.addEventListener("click", () => setMode("register"));
loginTab.addEventListener("click", () => setMode("login"));
document.getElementById("closeModal").addEventListener("click", closeModal);
modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

function toast(message) {
  const el = document.getElementById("toast");
  el.textContent = message;
  el.classList.remove("hidden");
  window.clearTimeout(window.toastTimer);
  window.toastTimer = window.setTimeout(() => el.classList.add("hidden"), 3600);
}
form.addEventListener("submit", e => {
  e.preventDefault();
  toast("Preview only: connect a secure authentication service before accepting real accounts.");
  notice.textContent = "This is a visual preview. No account was created and no password was sent anywhere. Configure Supabase Auth before launch.";
});
document.getElementById("tryDemo").addEventListener("click", () => {
  const result = Math.random() < 0.5 ? "UP" : "DOWN";
  const el = document.getElementById("sampleOutcome");
  el.textContent = result;
  el.style.color = result === "UP" ? "var(--mint)" : "#ff9bba";
  toast("Demo result only — not a real prediction.");
});